package org.wit.callback;

public interface TextWatcher
{
  void onTextChanged(String changedtext);
}