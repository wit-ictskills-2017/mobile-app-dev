package org.wit.callbackimpl;

import org.wit.callback.TextView;
import org.wit.callback.TextWatcher;

//Class to simulate a short-lived event loop
public class EventLoop implements TextWatcher
{

	public static void main(String[] args)
	{
		EventLoop event = new EventLoop();
		event.runLoop();
	}

	public void runLoop() 
	{
		TextView textview = new TextView();

		// EventLoop implements TextWatcher
		// Consequently, "this" is a legal parameter here
		textview.addTextChangedListener(this);

		// The simulated event loop
		int val = 0;
		do
		{
			if (val % 100 == 0)
			{
				textview.setPredicate(true); // the trigger to fire an event
			}
			textview.doWork();// invoked repeatedly and triggers event when predicate
			// true
			val += 1;
		} while (val < 500);// we expect 5 events to be triggered

	}

	@Override
	public void onTextChanged(String changedtext) {
		System.out.println(changedtext);	
	}
}
