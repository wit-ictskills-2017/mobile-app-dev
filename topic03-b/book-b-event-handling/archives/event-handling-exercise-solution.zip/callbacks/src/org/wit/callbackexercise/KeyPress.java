package org.wit.callbackexercise;

import org.wit.callback.TextView;

public class KeyPress extends TextView
{
  public void addKeyBoardListener(KeyBoardListener listener)
  {
    // Save the event object for later use.
    super.setTextWatcher(listener);
  }
  
  // This method will be invoked repeatedly in an event loop
  @Override
  public void doWork()
  {
    // Check the predicate, which is set elsewhere.
    if (getSomethingHappened())
    {
      // Signal the event by invoking the interface's method.
      //Invoke: onKeyBoardInput();
      ((KeyBoardListener)getTextWatcher()).onKeyBoardInput();
      //Invoke: onTextChanged("Finally - you called back");
      getTextWatcher().onTextChanged("Finally - you called back");
      setPredicate(false);
    }
  }
  
}
