package ie.cm.models;

public class Marker {
    public int id = 1;
    public Coords coords = new Coords();
}
