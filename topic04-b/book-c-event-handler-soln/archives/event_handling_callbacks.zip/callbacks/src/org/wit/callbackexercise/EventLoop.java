package org.wit.callbackexercise;

import java.util.Scanner;

import org.wit.callback.TextView;

//Class to simulate a short-lived event loop
public class EventLoop implements KeyBoardListener
{
	String keyboardInput;
	static Scanner in = new Scanner(System.in);

	public void runloop()
	{
		TextView textview = new KeyPress();
		// EventLoop implements KeyBoardListener
		// Consequently "this" a legal parameter here
		textview.addTextChangedListener(this);
		// The simulated event loop
		do
		{
			keyboardInput = keyboard();
			if (keyboardInput.equals("c"))
			{
				textview.setPredicate(true); // the trigger to fire an event
			}
			textview.doWork();//if predicate true then trigger event in doWork
		} while (keyboardInput.equals("q") == false);
		System.out.println("Thanks for your time - bye");
	}

	/*
	 * Capture and return a single keyboard character
	 */
	public String keyboard()
	{
		String s = "";
		if(in.hasNext())
		{
			s = in.next();
		}
		return s;
	}

	public static void main(String[] args)
	{
		EventLoop obj = new EventLoop();
		obj.runloop();
		in.close();
	}

	@Override
	public void onTextChanged(String changedtext) {
	    System.out.println(changedtext);   

	}

	@Override
	public void onKeyBoardInput() {
	    System.out.println("Keyboard input: " + keyboardInput);   
	}
}
