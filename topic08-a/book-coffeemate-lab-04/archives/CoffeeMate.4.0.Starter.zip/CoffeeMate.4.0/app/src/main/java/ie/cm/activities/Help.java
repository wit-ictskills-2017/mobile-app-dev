package ie.cm.activities;

import android.os.Bundle;

import ie.cm.R;

public class Help extends Base {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.help);
    }
}
