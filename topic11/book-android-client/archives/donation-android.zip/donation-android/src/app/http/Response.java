package app.http;

import java.util.List;

public interface Response<T>
{
  public void setReponse(List<T> aList);
  public void setReponse(T anObject);
  public void errorOccurred (Exception e);
}