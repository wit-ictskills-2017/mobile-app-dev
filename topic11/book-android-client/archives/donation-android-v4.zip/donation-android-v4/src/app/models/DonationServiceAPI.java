package app.models;

import java.util.List;
import android.content.Context;
import app.http.Request;
import app.http.Response;
import app.http.Rest;

public class DonationServiceAPI
{ 
  public static void getUsers(Context context, Response<User> response, String dialogMesssage)
  {
    new GetUsers(context, response, dialogMesssage).execute();
  }
  
  public static void createUser(Context context, Response<User> response, String dialogMesssage, User user)
  {
    new CreateUser(context, response, dialogMesssage).execute(user);
  }
  
  public static void getDonations(Context context, Response<Donation> response, String dialogMesssage)
  {
    new GetDonations(context, response, dialogMesssage).execute();
  }
  
  public static void createDonation(Context context, Response<Donation> response, String dialogMesssage, Donation donation)
  {
    new CreateDonation(context, response, dialogMesssage).execute(donation);
  }
}

class GetUsers extends Request
{
  public GetUsers(Context context, Response<User> callback, String message)
  {
    super(context, callback, message);
  }

  @Override
  protected List<User> doRequest(Object... params) throws Exception
  {
    String response =  Rest.get("/api/users");
    List<User> userList = JsonParsers.json2Users(response);
    return userList;
  }
}

class GetDonations extends Request
{
  public GetDonations(Context context, Response<Donation> callback, String message)
  {
    super(context, callback, message);
  }

  @Override
  protected List<Donation> doRequest(Object... params) throws Exception
  {
    String response =  Rest.get("/api/donations");
    List<Donation> donationList = JsonParsers.json2Donations(response);
    return donationList;
  }
}

class CreateUser extends Request
{ 
  public CreateUser(Context context, Response<User> callback, String message)
  {
    super(context, callback, message);
  }

  @Override
  protected User doRequest(Object... params) throws Exception
  {
    String response = Rest.post ("/api/users", JsonParsers.user2Json(params[0]));
    return JsonParsers.json2User(response);
  }
}

class CreateDonation extends Request
{
  public CreateDonation(Context context, Response<Donation> callback, String message)
  {
    super(context, callback, message);
  }

  @Override
  protected Donation doRequest(Object... params) throws Exception
  {
    String response = Rest.post ("/api/donations", JsonParsers.donation2Json(params[0]));
    return JsonParsers.json2Donation(response);
  }
}